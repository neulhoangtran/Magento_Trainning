Cái đoạn này là mình chuyển sản phẩm về đúng website của nó dựa nào field websites của Product và cả attribute
Product_redirect_to(dạng select option)
+ Trong này có lấy đc storeview code, id của storeview.
+ Mọi thông tin của 1 sản phẩm khi vào ở trang chi tiết của nó.
+ Lấy text của ô select option...


