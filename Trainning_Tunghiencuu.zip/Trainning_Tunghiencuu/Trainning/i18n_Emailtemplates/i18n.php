+ CÓ thể vào trong admin->congiguration->ganeral->locale rồi check value ở chỗ select option.
+ "cột gốc","cột mình muốn thay đổi","cột dành riêng cho mỗi module có thể có hoặc không, nếu k ghi thì nó sẽ đc cho toàn site luôn".
+